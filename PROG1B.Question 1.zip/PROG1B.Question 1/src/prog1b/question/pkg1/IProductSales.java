package prog1b.question.pkg1;

public interface IProductSales {
	int TotalSales(int[][] productSales);
	double AverageSales(int[][] productSales);
	int MaxSale(int[][] productSales);
	int MinSale(int[][] productSales);
}

