package prog6112question2;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class ProductSalesTest {

	private final ProductSales productSales = new ProductSales();

	@Test
	public void GetSalesOverLimit_ReturnsNumberOfSales() {
		assertEquals(2, productSales.GetSalesOverLimit());
	}

	@Test
	public void GetSalesUnderLimit_ReturnsNumberOfSales() {
		assertEquals(4, productSales.GetSalesUnderLimit());
	}
}

