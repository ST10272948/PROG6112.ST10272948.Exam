
package prog6112question2;

import javax.swing.SwingUtilities;

/**
 *
 * @author Lant3
 */
public class PROG6112Question2 {

    /**
     * @param args the command line arguments
     */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(() -> {
			SalesProcessorFrame frame = new SalesProcessorFrame();
			frame.setLocationRelativeTo(null);
			frame.setVisible(true);
		});
	}
    
}

