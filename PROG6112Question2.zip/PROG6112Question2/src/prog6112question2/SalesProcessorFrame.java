package prog6112question2;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class SalesProcessorFrame extends JFrame {

	private static final int SALES_LIMIT = 500;
	private static final DecimalFormat DECIMAL_FORMAT = new DecimalFormat("#,##0.00");
	private static final String DATASET_FILE_NAME = "dataset.txt";

	private final ProductSales productSales = new ProductSales();

	private final JTextArea inputArea;
	private final JTextArea dataArea;
	private final JLabel totalValueLabel;
	private final JLabel averageValueLabel;
	private final JLabel overLimitValueLabel;
	private final JLabel underLimitValueLabel;
	private final JLabel yearsValueLabel;

	public SalesProcessorFrame() {
		super("Product Sales Processor");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

 		// Product data display panel (read-only)
 		JPanel dataPanel = new JPanel(new BorderLayout(4, 4));
 		dataPanel.setBorder(BorderFactory.createTitledBorder("Product sales data"));
 		dataArea = new JTextArea();
 		dataArea.setEditable(false);
 		dataArea.setLineWrap(false);
 		JScrollPane dataScroll = new JScrollPane(dataArea);
 		dataScroll.setPreferredSize(new Dimension(280, 140));
 		JPanel dataControls = new JPanel(new BorderLayout(6, 6));
 		JPanel dataButtons = new JPanel();
 		JButton loadButton = new JButton("Load Data");
 		JButton saveButton = new JButton("Save Data");
 		dataButtons.add(loadButton);
 		dataButtons.add(saveButton);
 		JPanel yearsPanel = new JPanel();
 		yearsPanel.add(new JLabel("Years processed:"));
 		yearsValueLabel = new JLabel("-");
 		yearsPanel.add(yearsValueLabel);
 		dataControls.add(dataButtons, BorderLayout.WEST);
 		dataControls.add(yearsPanel, BorderLayout.EAST);
 		dataPanel.add(dataScroll, BorderLayout.CENTER);
 		dataPanel.add(dataControls, BorderLayout.SOUTH);
 
		// Input panel
		JPanel inputPanel = new JPanel(new BorderLayout(4, 4));
		inputPanel.setBorder(BorderFactory.createTitledBorder("Enter sales amounts (one per line)"));
		inputArea = new JTextArea();
		inputArea.setLineWrap(false);
		JScrollPane scrollPane = new JScrollPane(inputArea);
		scrollPane.setPreferredSize(new Dimension(120, 100));
		inputPanel.add(scrollPane, BorderLayout.CENTER);
		inputPanel.add(new JLabel("Current sales limit: " + SALES_LIMIT), BorderLayout.SOUTH);

		// Results panel
		JPanel resultsPanel = new JPanel(new GridBagLayout());
		resultsPanel.setBorder(BorderFactory.createTitledBorder("Results"));
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(4, 6, 4, 6);
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 0;
		gbc.gridy = 0;

		JLabel totalLabel = new JLabel("Total sales:");
		totalValueLabel = new JLabel("-");
		JLabel averageLabel = new JLabel("Average sales:");
		averageValueLabel = new JLabel("-");
		JLabel overLimitLabel = new JLabel("Count over limit (> " + SALES_LIMIT + "):");
		overLimitValueLabel = new JLabel("-");
		JLabel underLimitLabel = new JLabel("Count under limit (< " + SALES_LIMIT + "):");
		underLimitValueLabel = new JLabel("-");

		resultsPanel.add(totalLabel, gbc);
		gbc.gridx = 1;
		resultsPanel.add(totalValueLabel, gbc);
		gbc.gridx = 0;
		gbc.gridy++;
		resultsPanel.add(averageLabel, gbc);
		gbc.gridx = 1;
		resultsPanel.add(averageValueLabel, gbc);
		gbc.gridx = 0;
		gbc.gridy++;
		resultsPanel.add(overLimitLabel, gbc);
		gbc.gridx = 1;
		resultsPanel.add(overLimitValueLabel, gbc);
		gbc.gridx = 0;
		gbc.gridy++;
		resultsPanel.add(underLimitLabel, gbc);
		gbc.gridx = 1;
		resultsPanel.add(underLimitValueLabel, gbc);

		// Buttons panel
		JPanel buttonsPanel = new JPanel();
		JButton processButton = new JButton("Process");
		JButton clearButton = new JButton("Clear");
		JButton exitButton = new JButton("Exit");
		buttonsPanel.add(processButton);
		buttonsPanel.add(clearButton);
		buttonsPanel.add(exitButton);

		processButton.addActionListener(e -> processSales());
		clearButton.addActionListener(e -> clearAll());
		exitButton.addActionListener(e -> dispose());
		loadButton.addActionListener(e -> loadPresetData());
		saveButton.addActionListener(e -> saveDataToFile());
		createMenuBar(loadButton, saveButton, clearButton, exitButton);

		// Frame layout
		JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
		centerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		JPanel leftStack = new JPanel(new BorderLayout(8, 8));
		leftStack.add(dataPanel, BorderLayout.NORTH);
		leftStack.add(inputPanel, BorderLayout.CENTER);
		centerPanel.add(leftStack, BorderLayout.CENTER);
		centerPanel.add(resultsPanel, BorderLayout.EAST);
		add(centerPanel, BorderLayout.CENTER);
		add(buttonsPanel, BorderLayout.SOUTH);

		pack();
		setMinimumSize(new Dimension(680, getHeight()));
	}

	private void createMenuBar(JButton loadButton, JButton saveButton, JButton clearButton, JButton exitButton) {
		JMenuBar menuBar = new JMenuBar();

		JMenu fileMenu = new JMenu("File");
		JMenuItem exitItem = new JMenuItem("Exit");
		exitItem.addActionListener(exitButton.getActionListeners()[0]);
		fileMenu.add(exitItem);

		JMenu actionsMenu = new JMenu("Actions");
		JMenuItem loadItem = new JMenuItem("Load Product Data");
		loadItem.addActionListener(loadButton.getActionListeners()[0]);
		JMenuItem saveItem = new JMenuItem("Save Product Data");
		saveItem.addActionListener(saveButton.getActionListeners()[0]);
		JMenuItem clearItem = new JMenuItem("Clear");
		clearItem.addActionListener(clearButton.getActionListeners()[0]);
		actionsMenu.add(loadItem);
		actionsMenu.add(saveItem);
		actionsMenu.add(clearItem);

		menuBar.add(fileMenu);
		menuBar.add(actionsMenu);
		setJMenuBar(menuBar);
	}

	private void loadPresetData() {
		int[][] sales = productSales.GetProductSales();
		String[] names = productSales.getProductNames();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < names.length; i++) {
			sb.append(names[i]).append(" - ");
			for (int year = 0; year < sales[i].length; year++) {
				sb.append("Year ").append(year + 1).append(": ").append(sales[i][year]);
				if (year < sales[i].length - 1) {
					sb.append(", ");
				}
			}
			if (i < names.length - 1) {
				sb.append(System.lineSeparator());
			}
		}
		dataArea.setText(sb.toString());
		yearsValueLabel.setText(String.valueOf(productSales.GetProductsProcessed()));
		applyMetrics(productSales);
	}

	private void saveDataToFile() {
		if (dataArea.getText().trim().isEmpty()) {
			JOptionPane.showMessageDialog(this, "No product data to save. Load data first.", "Nothing to Save", JOptionPane.INFORMATION_MESSAGE);
			return;
		}
		File file = new File(DATASET_FILE_NAME);
		try (FileWriter writer = new FileWriter(file)) {
			writer.write(dataArea.getText());
			JOptionPane.showMessageDialog(this, "Data saved to:\n" + file.getAbsolutePath(), "Saved", JOptionPane.INFORMATION_MESSAGE);
		} catch (IOException ex) {
			JOptionPane.showMessageDialog(this, "Failed to save file:\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
 
	private void processSales() {
		String text = inputArea.getText().trim();
		if (text.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Please enter at least one sales amount.", "Input Required", JOptionPane.WARNING_MESSAGE);
			return;
		}

		List<Double> sales = new ArrayList<>();
		String[] lines = text.split("\\r?\\n");
		for (int i = 0; i < lines.length; i++) {
			String line = lines[i].trim();
			if (line.isEmpty()) {
				continue;
			}
			try {
				double value = Double.parseDouble(line);
				sales.add(value);
			} catch (NumberFormatException ex) {
				JOptionPane.showMessageDialog(
					this,
					"Invalid number on line " + (i + 1) + ": \"" + line + "\"",
					"Invalid Input",
					JOptionPane.ERROR_MESSAGE
				);
				return;
			}
		}

		if (sales.isEmpty()) {
			JOptionPane.showMessageDialog(this, "No valid sales numbers found.", "Input Required", JOptionPane.WARNING_MESSAGE);
			return;
		}

		double[] values = new double[sales.size()];
		for (int i = 0; i < sales.size(); i++) {
			values[i] = sales.get(i);
		}
		applyMetricsFromValues(values);
	}

	private void applyMetrics(IProductSales metricsSource) {
		totalValueLabel.setText(DECIMAL_FORMAT.format(metricsSource.GetTotalSales()));
		averageValueLabel.setText(DECIMAL_FORMAT.format(metricsSource.GetAverageSales()));
		overLimitValueLabel.setText(String.valueOf(metricsSource.GetSalesOverLimit()));
		underLimitValueLabel.setText(String.valueOf(metricsSource.GetSalesUnderLimit()));
	}

	private void applyMetricsFromValues(double[] values) {
		double total = 0.0;
		int overCount = 0;
		int underCount = 0;
		for (double v : values) {
			total += v;
			if (v > SALES_LIMIT) {
				overCount++;
			} else if (v < SALES_LIMIT) {
				underCount++;
			}
		}
		double average = total / values.length;

		totalValueLabel.setText(DECIMAL_FORMAT.format(total));
		averageValueLabel.setText(DECIMAL_FORMAT.format(average));
		overLimitValueLabel.setText(String.valueOf(overCount));
		underLimitValueLabel.setText(String.valueOf(underCount));
	}

	private void clearAll() {
		inputArea.setText("");
		totalValueLabel.setText("-");
		averageValueLabel.setText("-");
		overLimitValueLabel.setText("-");
		underLimitValueLabel.setText("-");
		inputArea.requestFocusInWindow();
	}
}


