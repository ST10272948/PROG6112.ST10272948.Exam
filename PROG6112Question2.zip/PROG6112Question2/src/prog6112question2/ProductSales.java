package prog6112question2;

import java.util.Arrays;

public class ProductSales implements IProductSales {

	private static final int SALES_LIMIT = 500;

	private static final String[] PRODUCT_NAMES = {
		"Microphone",
		"Speakers",
		"Mixing Desk"
	};

	private static final int[][] PRODUCT_SALES = {
		{300, 250},
		{150, 200},
		{700, 600}
	};

	@Override
	public int[][] GetProductSales() {
		int[][] copy = new int[PRODUCT_SALES.length][];
		for (int i = 0; i < PRODUCT_SALES.length; i++) {
			copy[i] = Arrays.copyOf(PRODUCT_SALES[i], PRODUCT_SALES[i].length);
		}
		return copy;
	}

	@Override
	public int GetTotalSales() {
		int total = 0;
		for (int[] product : PRODUCT_SALES) {
			for (int sales : product) {
				total += sales;
			}
		}
		return total;
	}

	@Override
	public int GetSalesOverLimit() {
		int count = 0;
		for (int[] product : PRODUCT_SALES) {
			for (int sales : product) {
				if (sales > SALES_LIMIT) {
					count++;
				}
			}
		}
		return count;
	}

	@Override
	public int GetSalesUnderLimit() {
		int count = 0;
		for (int[] product : PRODUCT_SALES) {
			for (int sales : product) {
				if (sales < SALES_LIMIT) {
					count++;
				}
			}
		}
		return count;
	}

	@Override
	public int GetProductsProcessed() {
		return PRODUCT_SALES.length == 0 ? 0 : PRODUCT_SALES[0].length;
	}

	@Override
	public double GetAverageSales() {
		int totalEntries = 0;
		int total = 0;
		for (int[] product : PRODUCT_SALES) {
			for (int sales : product) {
				total += sales;
				totalEntries++;
			}
		}
		return totalEntries == 0 ? 0.0 : (double) total / totalEntries;
	}

	public int getSalesLimit() {
		return SALES_LIMIT;
	}

	public String[] getProductNames() {
		return Arrays.copyOf(PRODUCT_NAMES, PRODUCT_NAMES.length);
	}
}

